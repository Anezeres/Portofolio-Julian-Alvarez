//import file from './../../public/assets/Enviroment/Futuristico.glb'

const Enviroment = () => {

    return (
        <>
            {/* <Enviroment files="/assets/Enviroment/" background={true}/> */}
        </>
    )
}

export default Enviroment;